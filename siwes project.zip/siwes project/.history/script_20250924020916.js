// Products List
const PRODUCTS = [
  { id: 1, name: "Jollof Rice", price: 1500, category: "rice", image: "images/" },
  { id: 2, name: "Fried Rice", price: 1700, category: "rice", image: "https://source.unsplash.com/400x300/?fried-rice" },
  { id: 3, name: "Grilled Chicken", price: 2500, category: "meat", image: "https://source.unsplash.com/400x300/?grilled-chicken" },
  { id: 4, name: "Beef Suya", price: 2000, category: "meat", image: "https://source.unsplash.com/400x300/?beef-skewers" },
  { id: 5, name: "Shawarma", price: 1200, category: "snacks", image: "https://source.unsplash.com/400x300/?shawarma" },
  { id: 6, name: "Pizza", price: 3000, category: "snacks", image: "https://source.unsplash.com/400x300/?pizza" },
  { id: 7, name: "Coca Cola", price: 500, category: "drinks", image: "https://source.unsplash.com/400x300/?coca-cola" },
  { id: 8, name: "Pepsi", price: 500, category: "drinks", image: "https://source.unsplash.com/400x300/?pepsi" },
  { id: 9, name: "Fresh Juice", price: 1000, category: "drinks", image: "https://source.unsplash.com/400x300/?juice" },
  { id: 10, name: "Smoothie", price: 1500, category: "drinks", image: "https://source.unsplash.com/400x300/?smoothie" }
];

let cart = JSON.parse(localStorage.getItem("cart")) || [];

// Display products
function displayProducts(products) {
  const container = document.getElementById("products");
  container.innerHTML = "";
  products.forEach(p => {
    const productDiv = document.createElement("div");
    productDiv.className = "product";
    productDiv.innerHTML = `
      <img src="${p.image}" alt="${p.name}">
      <h3>${p.name}</h3>
      <p>₦${p.price}</p>
      <button onclick="addToCart(${p.id})">Add to Cart</button>
    `;
    container.appendChild(productDiv);
  });
}

// Cart Functions
function addToCart(id) {
  const product = PRODUCTS.find(p => p.id === id);
  const item = cart.find(i => i.id === id);
  if (item) {
    item.qty++;
  } else {
    cart.push({ ...product, qty: 1 });
  }
  saveCart();
  renderCart();
}

function renderCart() {
  const itemsContainer = document.getElementById("cart-items");
  const totalContainer = document.getElementById("cart-total");
  itemsContainer.innerHTML = "";
  let total = 0;

  cart.forEach(item => {
    total += item.price * item.qty;
    const li = document.createElement("li");
    li.innerHTML = `
      ${item.name} x${item.qty} - ₦${item.price * item.qty}
      <button onclick="removeFromCart(${item.id})">❌</button>
    `;
    itemsContainer.appendChild(li);
  });

  totalContainer.innerText = `Total: ₦${total}`;
  document.getElementById("cart-count").innerText = cart.reduce((sum, i) => sum + i.qty, 0);
}

function removeFromCart(id) {
  cart = cart.filter(item => item.id !== id);
  saveCart();
  renderCart();
}

function clearCart() {
  cart = [];
  saveCart();
  renderCart();
}

function toggleCart() {
  document.getElementById("cart").classList.toggle("open");
}

function saveCart() {
  localStorage.setItem("cart", JSON.stringify(cart));
}

// Checkout
function checkout() {
  document.getElementById("checkout-modal").style.display = "block";
  const summary = document.getElementById("order-summary");
  summary.innerHTML = "<h3>Order Summary:</h3>";
  cart.forEach(item => {
    summary.innerHTML += `<p>${item.name} x${item.qty} - ₦${item.price * item.qty}</p>`;
  });
}

function closeCheckout() {
  document.getElementById("checkout-modal").style.display = "none";
}

document.getElementById("checkout-form").addEventListener("submit", e => {
  e.preventDefault();
  alert("Order placed successfully! Thank you for choosing AmaBites.");
  clearCart();
  closeCheckout();
});

// Filter
function filterProducts(category) {
  if (category === "all") displayProducts(PRODUCTS);
  else displayProducts(PRODUCTS.filter(p => p.category === category));
}

// Initialize
displayProducts(PRODUCTS);
renderCart();
